#.\run-migration.ps1 -MIGRATION_CONFIG_FILE migration-config.json -USERNAME_IMPORT alexander.hjelm@solidify.dev -USERNAME_EXPORT alexander.hjelm@solidify.dev -PAT_IMPORT XXX -PAT_EXPORT XXX
param(
    [String]$MIGRATION_CONFIG_FILE="",
    [String]$USERNAME_IMPORT="",
    [String]$USERNAME_EXPORT="",
    [String]$PAT_IMPORT="",
    [String]$PAT_EXPORT=""
)

$Config = Get-Content -Path $MIGRATION_CONFIG_FILE | ConvertFrom-Json
$i = 0
$Config | foreach {
    $adapter = $_.adapter
    $version = $_.version
    $config = $_.config
    $migrationJob = $_.migrationjob

    if($migrationJob -eq "Export") {
        $USERNAME = $USERNAME_EXPORT
        $PAT = $PAT_EXPORT
    } if($migrationJob -eq "Import") {
        $USERNAME = $USERNAME_IMPORT
        $PAT = $PAT_IMPORT
    }
    Write-Host $migrationJob
    Write-Host $PAT

    # Save config file
    $config | ConvertTo-Json -Depth 100 | Out-File "config-step-$i.json"
    .\synchub.exe run -n "$adapter" -v "$version" --config ".\config-step-$i.json" -u "$USERNAME" -p "$PAT"

    $i++
}
